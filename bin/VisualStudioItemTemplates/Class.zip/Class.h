/** \file $safeitemname$.h
 */
#ifndef $safeitemname$_h
#define $safeitemname$_h

#include <G3D/G3DAll.h>

/** \brief A $safeitemname$ */
class $safeitemname$ : public ReferenceCountedObject {
protected:

    $safeitemname$();

public:

    ~$safeitemname$();

    static shared_ptr<$safeitemname$> create();

};

#endif
