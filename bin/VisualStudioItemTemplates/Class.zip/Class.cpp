#include "$safeitemname$.h"

$safeitemname$::$safeitemname$() {}


$safeitemname$::~$safeitemname$() {}


shared_ptr<$safeitemname$> $safeitemname$::create() {
    return shared_ptr<$safeitemname$>(new $safeitemname$()); 
}
