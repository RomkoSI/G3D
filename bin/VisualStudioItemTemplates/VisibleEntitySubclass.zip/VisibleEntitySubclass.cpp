#include "$safeitemname$.h"

$safeitemname$::$safeitemname$() {}


shared_ptr<$safeitemname$> $safeitemname$::create 
    (const String&      name,
     Scene*             scene,
     AnyTableReader&    propertyTable,
     const ModelTable&  modelTable) {

    // Don't initialize in the constructor, where it is unsafe to throw Any parse exceptions
    shared_ptr<$safeitemname$> newEntity(new $safeitemname$());

    // Initialize each base class, which parses its own fields
    newEntity->Entity::init(name, scene, propertyTable);
    newEntity->VisibleEntity::init(propertyTable, modelTable);
    newEntity->$safeitemname$::init(propertyTable);

    // Verify that all fields were read by the base classes
    propertyTable.verifyDone();

    return newEntity;
}


shared_ptr<$safeitemname$> $safeitemname$::create 
(const String&                           name,
 Scene*                                  scene,
 const CFrame&                           position,
 const shared_ptr<Model>&                model) {

    // Don't initialize in the constructor, where it is unsafe to throw Any parse exceptions
    shared_ptr<$safeitemname$> newEntity(new $safeitemname$());

    // Initialize each base class, which parses its own fields
    newEntity->Entity::init(name, scene, position, shared_ptr<Entity::Track>(), true, true);
    newEntity->VisibleEntity::init(model, true, Surface::ExpressiveLightScatteringProperties(), Table<String, shared_ptr<UniversalMaterial> >(), ArticulatedModel::PoseSpline());
    newEntity->StartRingEntity::init();
 
    return newEntity;
}


void $safeitemname$::init(AnyTableReader& propertyTable) {
    // propertyTable.getIfPresent("myProperty", m_myProperty);
    init();
}


void $safeitemname$::init() {

}


Any $safeitemname$::toAny() const {
    Any a = VisibleEntity::toAny();
    a.setName("$safeitemname$");

    // a["myProperty"] = m_myProperty;

    return a;
}


void $safeitemname$::$safeitemname$(GameTime absoluteTime, GameTime _deltaTime) {
    // Do not call VisibleEntity::onSimulation; that will override this code with spline animation
    if (_deltaTime > 0) {
        m_previousFrame = m_frame;
    }

    simulatePose(absoluteTime, _deltaTime);
    
    if (isNaN(_deltaTime)) {
        // Instantaneously adjust to the new position
        m_previousFrame = m_frame;
    }
}
