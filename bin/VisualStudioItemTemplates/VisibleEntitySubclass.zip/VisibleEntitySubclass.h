/** \file $safeitemname$.h
 */
#ifndef $safeitemname$_h
#define $safeitemname$_h

#include <G3D/G3DAll.h>

/** \brief A $safeitemname$ */
class $safeitemname$ : public VisibleEntity {
protected:

    $safeitemname$();

    void init(AnyTableReader& propertyTable);
    
    void init();

public:

    /** For deserialization from Any / loading from file */
    static shared_ptr<$safeitemname$> create 
    (const String&                  name,
     Scene*                         scene,
     AnyTableReader&                propertyTable,
     const ModelTable&              modelTable);

    /** For programmatic construction at runtime */
    static shared_ptr<$safeitemname$> create 
    (const String&                  name,
     Scene*                         scene,
     const CFrame&                  position,
     const shared_ptr<Model>&       model);

    /** Converts the current VisibleEntity to an Any.  Subclasses should
        modify at least the name of the Table returned by the base class, 
        which will be "Entity" if not changed. */
    virtual Any toAny() const override;
    
    virtual void onSimulation(GameTime absoluteTime, GameTime deltaTime) override;
};

#endif
